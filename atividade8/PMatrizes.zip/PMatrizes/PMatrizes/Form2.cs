﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnexecutar_Click(object sender, EventArgs e)
        {
            string[] vetor = new string[2];
            int[] vetComp = new int[2];
            string nome;
            int i;

            for (i = 0; i < 2; i++)
            {
                nome = Interaction.InputBox("Digite o nome ", "Entrada de dados:");
                if (nome == "")
                {
                    MessageBox.Show("nome invalido!");
                    i--;
                }
                else
                {
                    vetComp[i] = nome.Replace(" ", "").Length;// ele tira o branco e vendo o branco;
                }

            }
            for (int j = 0; j < 2; j++)
            {
                lstnome.Items.Add($" nome:  {vetor[i]} tem{ vetor[j]} caracteres");

            }

        }
    }
}

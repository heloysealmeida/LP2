﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            Form2 novoForm = new Form2();

            novoForm.ShowDialog();

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i <= 20; i++) {
                auxiliar = Interaction.InputBox($"Digite o {i + 1} numero: ", "Entrada de dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor invalido");
                }

                Array.Reverse(vetor);
                auxiliar = "";

                auxiliar= string.Join("\n", vetor);

                MessageBox.Show("Auxilixar");



            }

        }

        private void btn2_Click(object sender, EventArgs e)
        {
            ArrayList aluno = new ArrayList
            {
                "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais"
            };
            aluno.Remove("Otávio");
            MessageBox.Show("Alunos: " + string.Join(", ", aluno.ToArray()));
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string resultado = "";
            for (int i = 0; i < 20; i++)
            {
                double soma = 0;
                for (int j = 0; j < 3; j++)
                {
                    double nota;
                    do
                    {
                        string entrada = Interaction.InputBox($"Aluno {i + 1} - Digite a nota {j + 1} (0 a 10):");
                        double.TryParse(entrada, out nota);
                    } while (nota < 0 || nota > 10);

                    notas[i, j] = nota;
                    soma += nota;
                }
                double media = soma / 3;
                resultado += $"Aluno {i + 1}: média {media:F1}\n";
            }
            MessageBox.Show(resultado, "Médias dos Alunos");
        }

        private void btn5_Click(object sender, EventArgs e)
        {
           Form3 form3 = new Form3();
            form3.ShowDialog();

            int RA = 2513030; 
            int N = RA % 10 + 1;
            if (RA % 10 == 0)
                N = 2;

            
            char[] gabarito = { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };

            
            char[,] respostas = new char[N, 10];

           
            for (int i = 0; i < N; i++)
            {
                MessageBox.Show($"Digite as respostas do aluno {i + 1}:");

                for (int j = 0; j < 10; j++)
                {
                    string entrada = Interaction.InputBox($"Aluno {i + 1} - Questão {j + 1}", "Entrada de Resposta").ToUpper();

                    
                    while (entrada != "A" && entrada != "B" && entrada != "C" && entrada != "D" && entrada != "E")
                    {
                        entrada = Interaction.InputBox($"⚠️ Resposta inválida! Digite apenas A, B, C, D ou E.\nAluno {i + 1} - Questão {j + 1}", "Entrada de Resposta").ToUpper();
                    }

                    respostas[i, j] = entrada[0];
                }
            }

            
            lstResultados.Items.Clear();

            for (int i = 0; i < N; i++)
            {
                int acertos = 0;
                for (int j = 0; j < 10; j++)
                {
                    if (respostas[i, j] == gabarito[j])
                        acertos++;
                }

                lstResultados.Items.Add($"Aluno {i + 1}: {acertos} acertos");
            }
        }
    }
}


        
    




﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class IMC : Form
    {
        double peso, altura, imc;
        public IMC()
        {
            InitializeComponent();
        }

        private void maskedTextBoxAltura_Validated(object sender, EventArgs e)
        {
            if (!(double.TryParse(maskedTextBoxAltura.Text, out altura)) || altura <= 0)
            {
                MessageBox.Show("Altura invalida");
            }
        }

        private void btnCalculo_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);
            maskedTextBoxImc.Text = imc.ToString("N");

            if (imc < 18.5)
            {
                MessageBox.Show("ta magrim demais meu fi!");
            }
            else if (imc <= 24.9)
            {
                MessageBox.Show("Corpinho simplesmente ESCULTURAL!");
            }
            else if(imc <= 29.9)
            {
                MessageBox.Show("Ta começando a ficar inchado!");
            }
            else if(imc<= 39.9)
            {
                MessageBox.Show("O BE SO!");
            }
            else {
                MessageBox.Show("Obesidade Grave,Jaime de carrossel");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            maskedTextBoxPeso.Clear();
            maskedTextBoxAltura.Clear();   
            maskedTextBoxImc.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void IMC_Load(object sender, EventArgs e)
        {

        }

        private void maskedTextBoxPeso_Validated(object sender, EventArgs e)
        {
            if (!(double.TryParse(maskedTextBoxPeso.Text, out  peso)) || peso > 900.00)
            {
                MessageBox.Show("Peso invalido");
            }


        }
    }
}
